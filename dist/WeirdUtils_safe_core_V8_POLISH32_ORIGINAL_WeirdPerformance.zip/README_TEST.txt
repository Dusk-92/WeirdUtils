WeirdUtils Safe Standalone Core Test V8 POLISH32

V32 = DEBUG30 stable exact-material pipeline
    + V31 additive/glow pass filtering
    + material-mask threshold -0.03
    + hard 3px JFA decode edge
    - V31 feather/soft edge

outline.dll
- Hard 3px outline; no feather.
- StateBlock Apply remains on IDirect3DStateBlock9 vtable slot 5.
- Explicit geometry / VS rebind retained.
- Exact-material replay retained.
- Additive/glow passes with DESTBLEND=ONE are skipped.
- Material scratch -> silhouette threshold remains -0.03.
- Forced Reset remains disabled.

customassets.dll / transmogfix.dll
- Same safe standalone variants as the V8 DEBUG branch.

weirdperformance.dll
- Not built or modified here.
- Keep the user's original WeirdPerformance binary unchanged.
